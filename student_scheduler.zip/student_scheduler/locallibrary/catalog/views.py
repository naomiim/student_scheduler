from django.shortcuts import render
from .models import Student, Course, Schedule

def index(request):
    # You can pass context data to the template if needed
    context = {}
    return render(request, 'catalog/index.html', context)

# View that displays the form for students to input their details
def student_form(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        student_id = request.POST.get('student_id')
        available_times = request.POST.get('available_times')
        student, created = Student.objects.get_or_create(student_id=student_id, defaults={'name': name, 'available_times': available_times})
        if not created:
            student.name = name
            student.available_times = available_times
            student.save()
        context = {'student': student}
        return render(request, 'catalog/student_form.html', context)
    else:
        return render(request, 'catalog/student_form.html')

# View that displays the form for students to input their available times and select courses
def schedule_form(request):
    if request.method == 'POST':
        student_id = request.POST.get('student_id')
        student = Student.objects.get(student_id=student_id)
        available_times = student.available_times.split(',')
        courses = Course.objects.all()
        context = {'student': student, 'available_times': available_times, 'courses': courses}
        return render(request, 'catalog/schedule_form.html', context)
    else:
        return render(request, 'catalog/student_form.html')

# View that generates the schedule based on the selected courses and the student's available times
def generate_schedule(request):
    if request.method == 'POST':
        student_id = request.POST.get('student_id')
        selected_courses = request.POST.getlist('courses')
        student = Student.objects.get(student_id=student_id)
        available_times = student.available_times.split(',')
        schedule = []

        # Loop through each selected course and find a suitable class time
        for course_id in selected_courses:
            course = Course.objects.get(id=course_id)
            class_time = find_class_time(course, available_times)
            # If a suitable class time is found, create a new Schedule object and add it to the schedule list
            if class_time:
                schedule.append(Schedule(student=student, course=course, class_time=class_time))
                available_times.remove(class_time)
        Schedule.objects.bulk_create(schedule)
        context = {'student': student, 'schedule': schedule}
        return render(request, 'catalog/schedule.html', context)
    else:
        return render(request, 'catalog/student_form.html')

# Function that finds a suitable class time for a course based on the student's available times
def find_class_time(course, available_times):
    class_times = course.class_times.split(',')
    for time in class_times:
        if time in available_times:
            return time
    return None
