from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('student/', views.student_form, name='student_form'),
    path('schedule/', views.schedule_form, name='schedule_form'),
    path('generate/', views.generate_schedule, name='generate_schedule'),
]
